package com.pengingat.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private var onPick: ((Uri) -> Unit)? = null
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) onPick?.invoke(u)
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        box.addView(TextView(this).apply { text = "Pengingat"; textSize = 30f; setTypeface(null, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = "Notifikasi tepat waktu, lengkap dengan catatan dan gambar." })
        box.addView(Button(this).apply {
            text = "+ Pengingat baru"
            setOnClickListener { showForm(null) }
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(list)
        val sv = ScrollView(this)
        sv.fitsSystemWindows = true
        sv.addView(box)
        setContentView(sv)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        list.removeAllViews()
        val all = Store.load(this).sortedBy { it.due }
        val fmt = SimpleDateFormat("EEE, d MMM yyyy HH:mm", Locale("id", "ID"))
        if (all.isEmpty()) {
            list.addView(TextView(this).apply { text = "\nBelum ada pengingat.\nKetuk \"+ Pengingat baru\" untuk memulai."; gravity = android.view.Gravity.CENTER })
            return
        }
        for (r in all) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
                setBackgroundColor(0x1A808080)
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (r.img.isNotEmpty() && File(r.img).exists()) {
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                row.addView(ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply { rightMargin = dp(12) }
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageBitmap(BitmapFactory.decodeFile(r.img, o))
                })
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply { text = r.title; textSize = 18f; setTypeface(null, Typeface.BOLD) })
            if (r.note.isNotEmpty()) col.addView(TextView(this).apply { text = r.note })
            val late = r.done && r.rep == 0
            val rep = when (r.rep) { 1 -> " · setiap hari"; 7 -> " · setiap minggu"; else -> "" }
            col.addView(TextView(this).apply {
                text = (if (late) "Sudah lewat · " else "") + fmt.format(r.due) + rep
                setTypeface(null, Typeface.BOLD)
            })
            row.addView(col)
            card.addView(row)
            val acts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            acts.addView(Button(this).apply { text = "Ubah"; setOnClickListener { showForm(r) } })
            acts.addView(Button(this).apply {
                text = "Hapus"
                setOnClickListener {
                    Scheduler.cancel(this@MainActivity, r)
                    if (r.img.isNotEmpty()) File(r.img).delete()
                    val l = Store.load(this@MainActivity)
                    l.removeAll { it.id == r.id }
                    Store.save(this@MainActivity, l)
                    render()
                }
            })
            card.addView(acts)
            list.addView(card)
        }
    }

    private fun saveImage(u: Uri): String {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 1200) s *= 2
        val opt = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opt) } ?: return ""
        val f = File(filesDir, "img_" + System.currentTimeMillis() + ".jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return f.absolutePath
    }

    private fun showForm(old: Reminder?) {
        val cal = Calendar.getInstance()
        cal.timeInMillis = old?.due ?: (System.currentTimeMillis() + 3600000L)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        var img = old?.img ?: ""
        val lay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val t = EditText(this).apply { hint = "Untuk apa? (contoh: Minum obat)"; setText(old?.title ?: "") }
        val n = EditText(this).apply {
            hint = "Catatan (opsional)"; setText(old?.note ?: ""); minLines = 2
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val prev = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(140))
            scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE
        }
        fun showPrev() {
            if (img.isNotEmpty() && File(img).exists()) {
                prev.setImageBitmap(BitmapFactory.decodeFile(img)); prev.visibility = View.VISIBLE
            } else prev.visibility = View.GONE
        }
        showPrev()
        val pick = Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener { onPick = { u -> img = saveImage(u); showPrev() }; picker.launch("image/*") }
        }
        val dateB = Button(this)
        val timeB = Button(this)
        fun upd() {
            dateB.text = "Tanggal: " + SimpleDateFormat("EEE, d MMM yyyy", Locale("id", "ID")).format(cal.time)
            timeB.text = "Jam: " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(cal.time)
        }
        upd()
        dateB.setOnClickListener {
            DatePickerDialog(this, DatePickerDialog.OnDateSetListener { _, y, m, d ->
                cal.set(Calendar.YEAR, y); cal.set(Calendar.MONTH, m); cal.set(Calendar.DAY_OF_MONTH, d); upd()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        timeB.setOnClickListener {
            TimePickerDialog(this, TimePickerDialog.OnTimeSetListener { _, h, mi ->
                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, mi); upd()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }
        val rep = Spinner(this)
        rep.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Sekali saja", "Setiap hari", "Setiap minggu"))
        rep.setSelection(when (old?.rep) { 1 -> 1; 7 -> 2; else -> 0 })
        for (v in listOf<View>(t, n, pick, prev, dateB, timeB, rep)) lay.addView(v)

        val d = AlertDialog.Builder(this)
            .setTitle(if (old == null) "Pengingat baru" else "Ubah pengingat")
            .setView(ScrollView(this).apply { addView(lay) })
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = t.text.toString().trim()
                val r = rep.selectedItemPosition
                val repeat = when (r) { 1 -> 1; 2 -> 7; else -> 0 }
                if (title.isEmpty()) { Toast.makeText(this, "Isi dulu untuk apa pengingatnya", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (repeat == 0 && cal.timeInMillis <= System.currentTimeMillis()) {
                    Toast.makeText(this, "Waktunya sudah lewat, pilih waktu lain", Toast.LENGTH_SHORT).show(); return@setOnClickListener
                }
                val id = old?.id ?: System.currentTimeMillis()
                val item = Reminder(id, title, n.text.toString().trim(), img, cal.timeInMillis, repeat)
                if (repeat > 0) { while (item.due <= System.currentTimeMillis()) item.due += repeat * 86400000L }
                val all = Store.load(this)
                val idx = all.indexOfFirst { it.id == id }
                if (idx >= 0) all[idx] = item else all.add(item)
                Store.save(this, all)
                Scheduler.cancel(this, item); Scheduler.set(this, item)
                render(); d.dismiss()
            }
        }
        d.show()
    }
}
