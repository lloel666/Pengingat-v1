package com.pengingat.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Reminder(
    val id: Long, var title: String, var note: String, var img: String,
    var due: Long, var rep: Int, var done: Boolean = false
)

object Store {
    fun load(c: Context): MutableList<Reminder> {
        val s = c.getSharedPreferences("pengingat", 0).getString("list", "[]") ?: "[]"
        val out = mutableListOf<Reminder>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Reminder(o.getLong("id"), o.getString("title"), o.optString("note"),
                    o.optString("img"), o.getLong("due"), o.optInt("rep"), o.optBoolean("done")))
            }
        } catch (e: Exception) { }
        return out
    }

    fun save(c: Context, l: List<Reminder>) {
        val a = JSONArray()
        for (r in l) {
            a.put(JSONObject().put("id", r.id).put("title", r.title).put("note", r.note)
                .put("img", r.img).put("due", r.due).put("rep", r.rep).put("done", r.done))
        }
        c.getSharedPreferences("pengingat", 0).edit().putString("list", a.toString()).apply()
    }
}

object Scheduler {
    private fun pi(c: Context, r: Reminder): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", r.id)
        return PendingIntent.getBroadcast(c, (r.id % 1000000000L).toInt(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun set(c: Context, r: Reminder) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = pi(c, r)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.due, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.due, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.due, p)
        }
    }

    fun cancel(c: Context, r: Reminder) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c, r))
    }
}

fun showReminder(c: Context, r: Reminder) {
    val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
        nm.createNotificationChannel(NotificationChannel("rem", "Pengingat", NotificationManager.IMPORTANCE_HIGH))
    }
    val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val text = if (r.note.isNotEmpty()) r.note else "Waktunya!"
    val b = NotificationCompat.Builder(c, "rem")
        .setSmallIcon(android.R.drawable.ic_popup_reminder)
        .setContentTitle(r.title).setContentText(text)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setDefaults(NotificationCompat.DEFAULT_ALL)
        .setContentIntent(open).setAutoCancel(true)
    val bmp = if (r.img.isNotEmpty() && File(r.img).exists()) BitmapFactory.decodeFile(r.img) else null
    if (bmp != null) b.setStyle(NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(text))
    else b.setStyle(NotificationCompat.BigTextStyle().bigText(text))
    try { NotificationManagerCompat.from(c).notify((r.id % 1000000000L).toInt(), b.build()) }
    catch (e: SecurityException) { }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", -1L)
        val all = Store.load(c)
        val r = all.firstOrNull { it.id == id } ?: return
        showReminder(c, r)
        if (r.rep > 0) {
            val step = r.rep * 86400000L
            while (r.due <= System.currentTimeMillis()) r.due += step
            Scheduler.set(c, r)
        } else r.done = true
        Store.save(c, all)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val all = Store.load(c)
        val now = System.currentTimeMillis()
        for (r in all) {
            if (r.done) continue
            if (r.due <= now) {
                if (r.rep > 0) {
                    val step = r.rep * 86400000L
                    while (r.due <= now) r.due += step
                    Scheduler.set(c, r)
                } else { showReminder(c, r); r.done = true }
            } else Scheduler.set(c, r)
        }
        Store.save(c, all)
    }
}
